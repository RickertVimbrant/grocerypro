from tkinter import *

# Create object
root = Tk()

# Adjust Size
root.geometry("1200x800")


root.configure(bg = "#FFFFFF")
canvas = Canvas(
    root,
    bg = "#FFFFFF",
    height = 800,
    width = 1200,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge")
canvas.place(x = 0, y = 0)

root.mainloop()
