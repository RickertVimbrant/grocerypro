import tkinter as tk
from tkinter import ttk
from tkinter import * 

# this is the function called when the button is clicked
def displayList():
	print('clicked')



root = Tk()

# This is the section of code which creates the main window
root.geometry('890x570')
root.configure(background='#F0F8FF')
root.title('Hello, I\'m the main window')


# First, we create a canvas to put the picture on
L= Canvas(root, height=300, width=300)
# Then, we actually create the image file to use (it has to be a *.gif)
picture_file = PhotoImage(file = 'C:/Users/theet/Desktop/anime/Programs/final2/final project folder/R.png')  # <-- you will have to copy-paste the filepath here, for example 'C:\Desktop\pic.gif'
# Finally, we create the image on the canvas and then place it onto the main window
L.create_image(300, 0, anchor=NE, image=picture_file)
L.place(x=578, y=6)


# This is the section of code which creates a button
Button(root, text='View List', bg='#F0F8FF', font=('arial', 24, 'normal'), command=displayList).place(x=48, y=476)


root.mainloop()

