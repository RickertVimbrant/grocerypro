import sys
import tkinter as tk
from tkinter import ttk
from tkinter import * 
import tkinter.messagebox
from tkinter.messagebox import askyesno
# this is the function called when the button is clicked
def displayList():
	print('clicked')
def closeAll():
        root.destroy()
# this is the function called when the button is clicked
def Exit():
        # create the root window
        root = tk.Tk()
        root.title('Tkinter Yes/No Dialog')
        root.geometry('300x150')

        # click event handler
        answer = askyesno(title='confirmation',
                    message='Are you sure that you want to quit?')
        if answer:
                tkinter.messagebox.showinfo("Farewell", "Shop well!")
                closeAll()
                root.destroy()

# this is a function to get the user input from the text input box
def getInputBoxValue():
	userInput = tInput.get()
	return userInput
# Create the main menu
# this is the function called when the button is clicked
def mainMenu():
        tkinter.messagebox.showinfo("Choices",'''### SHOPPING LIST ###

        Select a number for the action that you would like to do:

        1. View shopping list
        2. Add item to shopping list
        3. Remove item from shopping list
        4. Check if item is on shopping list
        5. How many items on shopping list
        6. Clear shopping list
        7. Exit
        ''')
        #prompt for input in box
        selection = input("Make your selection: ") # Ask the user to make a selection

        # Determine which action to perform based on the user's selection
        if selection == "1":
            displayList()            
        elif selection == "2":
            addItem()
        elif selection == "3":
            removeItem()
        elif selection == "4":
            checkItem()
        elif selection == "5":
            listLength()
        elif selection == "6":
            clearList()
        elif selection == "7":
            sys.exit()
        else:
            tkinter.messagebox.showinfo("You did not make a valid selection.")
root = Tk()

# This is the section of code which creates the main window
root.geometry('890x570')
root.configure(background='#F0F8FF')
root.title('Hello, I\'m the main window')


#old image method

# First, we create a canvas to put the picture on
#L= Canvas(root, height=300, width=300)
# Then, we actually create the image file to use (it has to be a *.gif)
#picture_file = PhotoImage(file = '')  # <-- you will have to copy-paste the filepath here, for example 'C:\Desktop\pic.gif'
# Finally, we create the image on the canvas and then place it onto the main window
#L.create_image(300, 0, anchor=NE, image=picture_file)
#L.place(x=578, y=6)
# Add image file

#new image method
bg = PhotoImage(file = "R.png")
  
# Create Canvas
canvas1 = Canvas( root, width = 400,
                 height = 400)
  
canvas1.pack(fill = "both", expand = True)
  
# Display image
canvas1.create_image( 0, 0, image = bg, 
                     anchor = "nw")

# This is the section of code which creates a button
Button(root, text='View List', bg='#F0F8FF', font=('arial', 24, 'normal'), command=displayList).place(x=48, y=476)


# This is the section of code which creates the a label
Label(root, text='Grocery lister pro', bg='#F0F8FF', font=('arial', 24, 'normal')).place(x=38, y=6)


# This is the section of code which creates a button
Button(root, text='Make Selection', bg='#F0F8FF', font=('arial', 24, 'normal'), command=mainMenu).place(x=298, y=476)


# This is the section of code which creates a button
Button(root, text='Exit', bg='#F0F8FF', font=('arial', 24, 'normal'), command=Exit).place(x=698, y=476)


# This is the section of code which creates a text input box
tInput=Entry(root)
tInput.place(x=28, y=86)


# This is the section of code which creates the a label
Label(root, text='Options', bg='#F0F8FF', font=('arial', 24, 'normal')).place(x=368, y=416)

#Definition and Logic for shopping list
shopping_list = ["apples", "bananas", "carrots", "potatoes"] # Add a few items to the shopping list

# Displays all items on the shopping list
#Make new window and display list
def displayList():
        root = Tk()
        root.geometry("400x400")
        #making listbox
        #defining visual for scroll bar
        myscroll = Scrollbar(root) 
        myscroll.pack(side = RIGHT, fill = Y)
        #listbox defined and scroll fuction added
        my_listbox = Listbox(root, yscrollcommand = myscroll.set )
        my_listbox.pack(pady=15)
        for item in shopping_list:
                my_listbox.insert(END, item)
                

# Adds an item to the shopping list
def addItem():
    item = input("Enter the item you wish to add to the shopping list: ")
    shopping_list.append(item)
    tkinter.messagebox.showinfo(item + " has been added to the shopping list.")

# Remove an item from the shopping list
def removeItem():
    item = input("Enter the item you wish to remove from the shopping list: ")
    if item in shopping_list:
        shopping_list.remove(item)
        tkinter.messagebox.showinfo(item + " has been removed from the shopping list.")
    else:
        tkinter.messagebox.showinfo("No, " + item + " is not on the shopping list.")

# Check to see if a particular item is on the shopping list
def checkItem():
    item = input("What item would you like to check on the shopping list: ")
    if item in shopping_list:
        tkinter.messagebox.showinfo("Yes, " + item + " is on the shopping list.")
    else:
        tkinter.messagebox.showinfo("No, " + item + " is not on the shopping list.")

# How many items are on the shopping list        
def listLength():
    tkinter.messagebox.showinfo("Length", "There are", len(shopping_list), "items on the shopping list.")

# Remove everything from the shopping list
def clearList():
    shopping_list.clear()
    tkinter.messagebox.showinfo("The shopping list is now empty.")
#End of Logic
    
root.mainloop()
