import sys
import tkinter as tk
from tkinter import ttk
from tkinter import * 
import tkinter.messagebox
from tkinter.messagebox import askyesno
from PIL import ImageTk,Image
# this is the function called when the button is clicked
# Displays all items on the shopping list
#Make new window and display list
def displayList():
        root = Tk()
        root.geometry("400x400")
        #photo
        my_img = ImageTk.PhotoImage(Image.open("C.png"))
        my_label = Label(image=my_img)
        my_label.pack
        #making listbox
        #defining visual for scroll bar
        myscroll = Scrollbar(root) 
        myscroll.pack(side = RIGHT, fill = Y)
        #listbox defined and scroll fuction added
        my_listbox = Listbox(root, yscrollcommand = myscroll.set )
        my_listbox.pack(pady=15)
        for item in shopping_list:
                my_listbox.insert(END, item)
def closeAll():
        root.destroy()
# this is the function called when the button is clicked
def Exit():
        # create the root window
        root = tk.Tk()
        root.title('Tkinter Yes/No Dialog')
        root.geometry('300x150')

        # click event handler
        answer = askyesno(title='confirmation',
                    message='Are you sure that you want to quit?')
        if answer:
                tkinter.messagebox.showinfo("Farewell", "Shop well!")
                closeAll()
                root.destroy()

# Create the main menu
# this is the function called when the button is clicked
def mainMenu():
        # String showing list of choices
        tkinter.messagebox.showinfo("Choices",'''### SHOPPING LIST ###

        Select a number for the action that you would like to do:

        1. View shopping list
        2. Clear shopping list
        3. Exit
        ''')
        #prompt for input in box
        #selection = input("Make your selection: ") # Ask the user to make a selection
        #selection window for user input
        root = Tk()
        root.geometry ('1000x1000')
                          
        
        myButton1 = Button(root, text="View list.", command=displayList)
        myButton1.grid(row=1, column=0)

        myButton2 = Button(root, text="Clear list.", command=clearList)
        myButton2.grid(row=1, column=5)

        myButton3 = Button(root, text="Exit.", command=Exit)
        myButton3.grid(row=1, column=6)
        
        
        
        
                
root = Tk()

# This is the section of code which creates the main window
root.geometry('890x570')
root.configure(background='#F0F8FF')
root.title('Hello, I\'m the main window')




#new image method
bg = PhotoImage(file = "R.png")
  
# Create Canvas
canvas1 = Canvas( root, width = 400,
                 height = 400)
  
canvas1.pack(fill = "both", expand = True)
  
# Display image
canvas1.create_image( 0, 0, image = bg, 
                     anchor = "nw")

# This is the section of code which creates a button
Button(root, text='View List', bg='#F0F8FF', font=('arial', 24, 'normal'), command=displayList).place(x=48, y=476)


# This is the section of code which creates the a label
Label(root, text='Grocery lister pro', bg='#F0F8FF', font=('arial', 24, 'normal')).place(x=38, y=6)


# This is the section of code which creates a button
Button(root, text='Make Selection', bg='#F0F8FF', font=('arial', 24, 'normal'), command=mainMenu).place(x=298, y=476)


# This is the section of code which creates a button
Button(root, text='Exit', bg='#F0F8FF', font=('arial', 24, 'normal'), command=Exit).place(x=698, y=476)



# This is the section of code which creates the a label
Label(root, text='Options', bg='#F0F8FF', font=('arial', 24, 'normal')).place(x=368, y=416)

#Definition and Logic for shopping list
shopping_list = ["apples", "bananas", "carrots", "potatoes"] # Add a few items to the shopping list
                

# Adds an item to the shopping list
def addItem():
    root = Tk()
    
    canvas1 = tk.Canvas(root, width = 400, height = 300)
    canvas1.pack()
    entry1 = tk.Entry (root) 
    canvas1.create_window(200, 140, window=entry1)
    button1 = tk.Button(text='add', command=addNow)
    button1.grid(row=1, column=0)
def addNow():
        item=entry1.get()    
        shopping_list.append(item)
        tkinter.messagebox.showinfo("Added",item + " has been added to the shopping list.")
            
# Remove an item from the shopping list
def removeItem():
    item = input("Enter the item you wish to remove from the shopping list: ")
    if item in shopping_list:
        shopping_list.remove(item)
        tkinter.messagebox.showinfo("Removed!",item + " has been removed from the shopping list.")
    else:
        tkinter.messagebox.showinfo("Missing","No, " + item + " is not on the shopping list.")

# Check to see if a particular item is on the shopping list

 # How many items are on the shopping list        


# Remove everything from the shopping list
def clearList():
    shopping_list.clear()
    tkinter.messagebox.showinfo("Clear","The shopping list is now empty.")
#End of Logic
    
root.mainloop()
